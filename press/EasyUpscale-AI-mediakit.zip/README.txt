EasyUpscale AI: press kit
=========================

logos/         The icon and the full logo (PNG, transparent). Use the "for light background" logo on light pages
               and the "for dark background" one on dark pages. Please do not stretch, recolor or add effects.
screenshots/   The app in English (en) and Czech (cs), 2400 px wide, JPEG.
fact-sheet-*   Facts, descriptions and brand colors (Markdown), English and Czech.

Web: https://easyupscaleai.com/
Contact: info@easyupscaleai.com
Maker: Daniel Mazura, Šestajovice, Czech Republic (Company ID 19809735)
