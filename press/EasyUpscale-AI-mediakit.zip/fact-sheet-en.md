# EasyUpscale AI: press kit

Everything a journalist, blogger or reviewer needs: the facts, ready-to-use descriptions, logos and screenshots. All of it may be used when writing about EasyUpscale AI.

## In one sentence

EasyUpscale AI enlarges and enhances photos with AI on your own Windows PC: no cloud, no subscription, no queue.

## Short description (about 50 words)

EasyUpscale AI is a Windows app that enlarges and enhances photos with artificial intelligence on your own graphics card. Nothing is uploaded. Auto mode picks the model by itself, Advanced mode gives full control, and a before-and-after slider shows what changed. It is free (up to 2×, no watermark); a one-time license adds 4× enlarging.

## Long description

Most AI upscalers are websites: you upload a photo, wait in a queue and pay per picture or per month. EasyUpscale AI works the other way round. The AI runs on your own graphics card (NVIDIA, AMD or Intel, through DirectX 12), so your pictures never leave your computer, there is no file size limit set by a service and no subscription.

In Auto mode the app looks at the picture and picks the model, the enlargement and the look. Advanced mode lets you choose a model, blend two of them, set the output size (2×, 4×, 4K, Full HD) and fine-tune sharpness and noise. A live before-and-after slider shows exactly what changed. Whole folders can be enlarged in a batch, and a watched folder enlarges new pictures in the background. The app saves PNG, JPEG, WebP, AVIF, TIFF and BMP and keeps transparency and metadata.

The free version enlarges up to 2× with no watermark. A one-time license of €14.99 (website or Microsoft Store) unlocks 4× enlarging.

## Key facts

- **Product:** EasyUpscale AI
- **Current version:** 1.0.18
- **Platform:** Windows 10 and 11 (64-bit); a DirectX 12 graphics card (NVIDIA, AMD or Intel); about 1 GB of disk space; 8 GB of RAM recommended
- **Price:** free up to 2×, no watermark; €14.99 one-time license (4×), no subscription
- **Languages of the app:** 15 (English, Czech, German, Polish, French, Spanish, Italian, Portuguese, Dutch, Russian, Ukrainian, Turkish, Japanese, Korean, Chinese)
- **Technology:** models run locally through ONNX Runtime and DirectML. Real-ESRGAN (BSD-3-Clause) and SwinIR (Apache-2.0) models, plus an own text model
- **Privacy:** pictures are never uploaded. Only the license key and the computer name are sent when a license is activated or checked
- **Output formats:** PNG, JPEG, WebP, AVIF, TIFF, BMP
- **Website:** [easyupscaleai.com](https://easyupscaleai.com/)
- **Download:** [github.com/danielcorfer/easyupscale-web/releases/latest](https://github.com/danielcorfer/easyupscale-web/releases/latest)

## About the maker

EasyUpscale AI is made by one person, **Daniel Mazura**, a sole trader in Šestajovice near Prague, Czech Republic (Company ID 19809735). There is no investor and no advertising behind it. More on the [About page](about.html).

## Brand

- **Name:** EasyUpscale AI ("EasyUpscale" is one word, followed by "AI")
- **Colors:** the logo gradient runs from deep indigo `#5008C9` through violet `#801CE5` to magenta `#BD29EE`. The product violet is `#7B22DB`. The app background is near black `#0D0B11`
- **Typeface:** Outfit, SIL Open Font License 1.1
- **Logos:** the ZIP has the icon on its own and the full logo for light and dark backgrounds. Please do not stretch, recolor or add effects to them

## Contact

Press questions and interviews: [info@easyupscaleai.com](mailto:info@easyupscaleai.com).
