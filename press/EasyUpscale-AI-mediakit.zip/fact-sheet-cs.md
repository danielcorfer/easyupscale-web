# EasyUpscale AI: materiály pro média

Všechno, co potřebuje novinář, bloger nebo recenzent: fakta, hotové popisy, loga a screenshoty. Všechno můžete při psaní o EasyUpscale AI použít.

## Jednou větou

EasyUpscale AI zvětšuje a vylepšuje fotky pomocí AI přímo na vašem Windows PC: bez cloudu, bez předplatného, bez čekání ve frontě.

## Krátký popis (cca 50 slov)

EasyUpscale AI je aplikace pro Windows, která zvětšuje a vylepšuje fotky umělou inteligencí na vaší grafické kartě. Nic se nenahrává. Režim Auto sám zvolí model, režim Pokročilý nabízí plnou kontrolu a posuvník před a po ukáže, co se změnilo. Zdarma na vyzkoušení, jednorázová licence odstraní vodoznak.

## Dlouhý popis

Většina AI zvětšovačů jsou weby: nahrajete fotku, čekáte ve frontě a platíte za obrázek nebo za měsíc. EasyUpscale AI funguje obráceně. AI běží na vaší grafické kartě (NVIDIA, AMD i Intel přes DirectX 12), takže vaše obrázky počítač neopouštějí, služba nestanovuje limit velikosti souboru a nejde o předplatné.

V režimu Auto aplikace obrázek posoudí a sama zvolí model, zvětšení i vzhled. Režim Pokročilý umožňuje vybrat model, smíchat dva, nastavit výslednou velikost (2×, 4×, 4K, Full HD) a doladit ostrost a šum. Živý posuvník před a po přesně ukáže, co se změnilo. Celé složky lze zvětšit dávkou a sledovaná složka zvětšuje nové obrázky na pozadí. Aplikace ukládá PNG, JPEG, WebP, AVIF, TIFF i BMP a zachovává průhlednost a metadata.

Všechny funkce fungují i bez licence, zdarma verze jen přidává vodoznak přes výsledek. Jednorázová licence za 4,99 € (časově omezená cena, běžně 14,99 €) ho odstraní.

## Klíčová fakta

- **Produkt:** EasyUpscale AI
- **Aktuální verze:** 1.0.18
- **Platforma:** Windows 10 a 11 (64bit); grafika s DirectX 12 (NVIDIA, AMD nebo Intel); asi 1 GB na disku; doporučeno 8 GB RAM
- **Cena:** zdarma na vyzkoušení s vodoznakem; jednorázová licence 4,99 € (časově omezená cena, běžně 14,99 €), bez předplatného
- **Jazyky aplikace:** 15 (angličtina, čeština, němčina, polština, francouzština, španělština, italština, portugalština, nizozemština, ruština, ukrajinština, turečtina, japonština, korejština, čínština)
- **Technologie:** modely běží lokálně přes ONNX Runtime a DirectML. Modely Real-ESRGAN (BSD-3-Clause) a SwinIR (Apache-2.0) a vlastní textový model
- **Soukromí:** obrázky se nikdy nenahrávají. Při aktivaci a ověření licence se posílá jen licenční klíč a název počítače
- **Výstupní formáty:** PNG, JPEG, WebP, AVIF, TIFF, BMP
- **Web:** [easyupscaleai.com](https://easyupscaleai.com/cs/)
- **Stažení:** [github.com/danielcorfer/easyupscale-web/releases/latest](https://github.com/danielcorfer/easyupscale-web/releases/latest)

## O autorovi

EasyUpscale AI dělá jeden člověk, **Daniel Mazura**, OSVČ ze Šestajovic u Prahy (IČO 19809735). Nestojí za ním žádný investor ani reklama. Více na stránce [O projektu](about.html).

## Značka

- **Název:** EasyUpscale AI („EasyUpscale“ se píše dohromady, za ním „AI“)
- **Barvy:** přechod loga vede od tmavě indigové `#5008C9` přes fialovou `#801CE5` po purpurovou `#BD29EE`. Produktová fialová je `#7B22DB`. Pozadí aplikace je téměř černé `#0D0B11`
- **Písmo:** Outfit, SIL Open Font License 1.1
- **Loga:** v ZIPu je samotná ikona a celé logo pro světlé a tmavé pozadí. Prosíme, neroztahujte je, nepřebarvujte a nepřidávejte jim efekty

## Kontakt

Dotazy novinářů a rozhovory: [info@easyupscaleai.com](mailto:info@easyupscaleai.com).
